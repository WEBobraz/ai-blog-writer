# Next JS & Open AI / GPT: Next-generation Next JS & AI apps

This is the starter repo for the [Next JS & Open AI / GPT: Next-generation Next JS & AI apps course](https://gale.udemy.com/course/next-js-ai/).
